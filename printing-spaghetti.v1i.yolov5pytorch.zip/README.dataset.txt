# printing-spaghetti > 2023-06-19 2:16pm
https://universe.roboflow.com/hakureimu-qdiyj/printing-spaghetti

Provided by a Roboflow user
License: CC BY 4.0

